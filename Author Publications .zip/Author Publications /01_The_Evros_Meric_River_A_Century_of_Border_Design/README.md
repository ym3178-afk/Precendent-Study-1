# The Evros/Meriç River: A Century of Border Design
https://forensic-architecture.org/investigation/the-evros-meric-river-a-century-of-border-design
